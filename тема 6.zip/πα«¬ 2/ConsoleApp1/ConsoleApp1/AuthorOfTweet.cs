﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class AuthorOfTweet
    {
        string name;
        bool authentic;
        string hrefName; //Cсылка на твитер аккаунт, через @

       public AuthorOfTweet(string name, bool authentic, string hrefName)
        {
            this.name = name;
            this.authentic = authentic;
            this.hrefName = hrefName;

        }
    }
}
