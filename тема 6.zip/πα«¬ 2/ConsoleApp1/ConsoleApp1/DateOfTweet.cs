﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class DateOfTweet
    {
        int day;
        int mounth;
        int year;

        public DateOfTweet(int day, int mounth, int year) {
            this.day  = day;
            this.mounth = mounth;
            this.year = year;

            }
    }
}
