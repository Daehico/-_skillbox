﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class viewATweet
    {
        textOfTweet TextOfTweet;
        DateOfTweet DateOfTweet;
        AuthorOfTweet AuthorOfTweet;
        

        public void view(textOfTweet textOfTweet, DateOfTweet dateOfTweet, AuthorOfTweet authorOfTweet)
        {

        }

    

    }
}
