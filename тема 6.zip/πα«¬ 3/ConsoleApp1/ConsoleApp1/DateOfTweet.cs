﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class DateOfTweet
    {
       private int day;
       private int mounth;
        private int year;

        public DateOfTweet(int day, int mounth, int year) {
            this.day  = day;
            this.mounth = mounth;
            this.year = year;

            }

        public int Day
        {
            get
            {
                return this.day;
            }

        }

        public int Mounth
        {
            get
            {
                return this.mounth;
            }

        }

        public int Year
        {
            get
            {
                return this.year;
            }

        }
    }
}
