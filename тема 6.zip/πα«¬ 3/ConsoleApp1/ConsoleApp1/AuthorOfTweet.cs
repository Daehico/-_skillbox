﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class AuthorOfTweet
    {
        private string name;
       private bool authentic;
       private string hrefName; //Cсылка на твитер аккаунт, через @

       public AuthorOfTweet(string name, bool authentic, string hrefName)
        {
            this.name = name;
            this.authentic = authentic;
            this.hrefName = hrefName;

        }
        public string Name
        {
            get
            {
                return this.name;
            }

        }

        public bool Authentic
        {
            get
            {
                return this.authentic;
            }

        }

        public string HrefName
        {
            get
            {
                return this.hrefName;
            }

        }
    }
}
