﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            double min = double.MinValue;
            double max = double.MaxValue;

            Console.WriteLine(min);
            Console.WriteLine(max);
            Console.ReadKey();
        }
        
    }
}
