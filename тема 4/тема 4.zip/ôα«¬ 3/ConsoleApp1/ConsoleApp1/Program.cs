﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace ConsoleApp1
{
    class Program
    {
        static void Main(string[] args)
        {
            string text = Console.ReadLine();

            var a = text.Substring(0, Math.Min(150, text.Length));
            Console.WriteLine(a);
            var values = a.Split(' ', ',', '.', '?', '!');
            string wordWithMaxLength = string.Empty;
            Console.WriteLine("Самое длинное слово:" + values.Length);

            for (int i = 0; i < values.Length; i++)
                if (values[i].Length > wordWithMaxLength.Length)
                    wordWithMaxLength = values[i];
            Console.WriteLine("Самое длинное слово:" + wordWithMaxLength);
         
            Console.ReadKey();
        }
    }
}
