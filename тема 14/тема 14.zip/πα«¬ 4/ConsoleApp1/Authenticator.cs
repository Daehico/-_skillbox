﻿using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Security.Policy;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using TweetSharp;

namespace ConsoleApp1
{
    class Authenticator
    {


        //public static object Authenticators()
        //{
        //     public const string consumerKey = "x6roMQs0MZ1PwjNmAELfziqq9";
        //public const string consumerSecret = "LztwfuCe5wFMbTh2i5MmCuBCcog2taz39Jfock7CiCJbooWWJP";
        //public static TwitterService service = new TwitterService(consumerKey, consumerSecret);

        //public static OAuthRequestToken requestToken = service.GetRequestToken();

        //public Uri uri = service.GetAuthorizationUri(requestToken);
        //Process.Start(uri.ToString());

        //  public static string verifier = Console.ReadLine();
        //public static OAuthAccessToken access = service.GetAccessToken(requestToken, verifier);

        //void a = service.AuthenticateWith(access.Token, access.TokenSecret);
        //IEnumerable<TwitterStatus> mentions = service.ListTweetsMentioningMe();   



        //    return service;
        //}
    }
}






